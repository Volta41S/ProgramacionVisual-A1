﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class VerificarNumero
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        VerificarTipoNumero()
    End Sub

    'Verifica si el numero es par o impar'
    Private Sub VerificarTipoNumero()
        Dim numero As Integer
        numero = CInt(TextBox1.Text)
        TextBox3.Text = ""
        If 0 = numero Mod 2 Then
            TextBox3.Text = "Es par"
        Else
            TextBox3.Text = "Es impar"
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox3.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FMenu.Show()
        TextBox1.Text = ""
        TextBox3.Text = ""
        Me.Hide()
    End Sub

    'Evita que se añada texto en las cajas'
    Private Sub txtlevantamiento_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

End Class