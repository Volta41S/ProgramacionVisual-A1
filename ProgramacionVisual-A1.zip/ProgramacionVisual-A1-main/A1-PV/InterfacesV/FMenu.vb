﻿Imports System.Drawing.Text

Public Class FMenu
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    'Botones de estructura repetitiva'
    Private Sub BtnRepetitiva1_Click(sender As Object, e As EventArgs)
        FBase.Show()
        Me.Hide()
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Temporizador.Show()
        Me.Hide()
    End Sub

    'Botones de estructura selectiva'
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FBase2.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        FRandom.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        VerificarNumero.Show()
        Me.Hide()
    End Sub


End Class
