﻿Public Class Temporizador
    'Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Int32)
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        sumar()

    End Sub

    'Evita que se añada texto en las cajas'
    Private Sub txtlevantamiento_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox3.Text = ""
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub
    'Contador del temporizador'
    Public Async Sub sumar()
        Dim numero, contador As Integer
        numero = CInt(TextBox1.Text)
        contador = 0
        TextBox3.Text = CStr(contador) + vbNewLine
        Await Task.Delay(1000)
        Do
            'TextBox3.Text = ""
            contador = contador + 1
            TextBox3.Text += CStr(contador) + vbNewLine
            Await Task.Delay(1000)
        Loop While contador < numero
        MsgBox("¡El tiempo ha terminado!")
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FMenu.Show()
        Me.Hide()
    End Sub
End Class